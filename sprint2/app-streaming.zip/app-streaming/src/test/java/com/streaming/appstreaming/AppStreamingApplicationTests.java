package com.streaming.appstreaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppStreamingApplicationTests {

	@Test
	void contextLoads() {
	}

}
