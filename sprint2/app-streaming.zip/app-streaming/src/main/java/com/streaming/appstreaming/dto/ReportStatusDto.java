package com.streaming.appstreaming.dto;

public class ReportStatusDto {
    public Integer completed;
    public Integer cancelled;
}
