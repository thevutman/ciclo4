package com.streaming.appstreaming.security;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
}
