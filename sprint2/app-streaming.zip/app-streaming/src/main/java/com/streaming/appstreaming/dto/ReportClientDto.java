package com.streaming.appstreaming.dto;

public class ReportClientDto {
    public String id;
    public String email;
    public String birthDate;
}
