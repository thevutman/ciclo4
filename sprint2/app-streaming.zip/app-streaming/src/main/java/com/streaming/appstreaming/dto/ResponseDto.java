package com.streaming.appstreaming.dto;

public class ResponseDto {
    public Boolean status;
    public String message;
    public String id;
}
